using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Enemy Stats")]
    public float maxHealth = 50f;
    public float currentHealth;
    public float moveSpeed = 3f;
    public int damageAmount = 10;

    void Start()
    {
        currentHealth = maxHealth;
    }

    // ฟังก์ชันรับดาเมจ (ให้คนที่ 1 เรียกใช้เมื่อยิงโดน)
    public void TakeDamage(float damage)
    {
        currentHealth -= damage;

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        // TODO: สั่งให้ดรอปไอเทม (ส่วนของคนที่ 3)
        Destroy(gameObject); // ทำลายตัวเองเมื่อ HP หมด
    }
}